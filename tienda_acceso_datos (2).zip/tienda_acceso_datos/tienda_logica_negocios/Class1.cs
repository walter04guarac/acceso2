﻿using System;
using System.Collections.Generic;
<<<<<<< HEAD
<<<<<<< HEAD
using System.Runtime.Remoting.Contexts;

namespace tienda_logica_negocios
{
    public class ServicioProducto
    {
        public class ApplicationDbContext : DbContext
        {
            public DbSet<Producto> Productos { get; set; }

            internal void SaveChanges()
            {
                throw new NotImplementedException();
            }
        }

        private readonly ApplicationDbContext _context;

        public ServicioProducto(ApplicationDbContext context)
        {
            _context = context;
        }

        public void CrearNuevoProducto(string nombre)
        {
            // Lógica de negocio...
            var nuevoProducto = new Producto { Nombre = nombre };
            _context.Productos.Add(nuevoProducto);
            _context.SaveChanges();
        }

        public Producto ObtenerProductoPorId(int id)
        {
            // Lógica de negocio...
            return _context.Productos.Find(id);
        }

        public class DbContext
        {
        }

        // Otros métodos de lógica de negocio...
    }

    public class DbSet<T>
    {
    }

    internal class Producto
    {
        public string Nombre { get; set; }
=======
=======
>>>>>>> 0b01f5056825a413d87d96962fc5f00821406764
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tienda_logica_negocios
{
    public class Class1
    {
        private int number { get; set; }
<<<<<<< HEAD
>>>>>>> 0b01f5056825a413d87d96962fc5f00821406764
=======
>>>>>>> 0b01f5056825a413d87d96962fc5f00821406764
    }
}
