﻿namespace tienda_logica_negocios.Entities
{
    internal class Admin_employeeBase
    {
        public string Cargo;
        public int Id;
        public string Nombre;
    }
}