﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tienda_logica_negocios.Entities
{
    internal class Client
    {
<<<<<<< HEAD
<<<<<<< HEAD
        internal readonly object id_client;

=======
>>>>>>> 0b01f5056825a413d87d96962fc5f00821406764
=======
>>>>>>> 0b01f5056825a413d87d96962fc5f00821406764
        private int id_cliente { get; set; }
        public string nombre { get; set; }
        public string apellido { get; set; }
    }
}
