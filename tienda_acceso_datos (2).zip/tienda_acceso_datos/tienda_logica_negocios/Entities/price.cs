﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tienda_logica_negocios.Entities
{
    internal class price
    {
        private int id_precio {  get; set; }
        public string valor { get; set; }
        public string fecha { get; set; }
    }
}
